
Installation:
-------------
The included package can be installed manually using dpkg, or 
using the included script:

sudo ./install.run


Usage:
------
Once installed, the debugger can be activated using the command line:
debugui <application executable path>

The debugger window has
* a left pane of source files
* a bottom pane for watch expressions
* double click a line to toggle a breakpoint
* Toolbar for  next / step / continue / etc...
  Keyboard shortcuts are similar to Visual Studio  (F10/F11/F5)
* During a break, hover above a variable to get a tooltip with its value


