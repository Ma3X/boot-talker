'''
Stephen Bradshaws Python gdb extensions

Copyright (c) 2013, Stephen Bradshaw
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
    * Neither the name of the organization nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Visit my blog: http://www.thegreycorner.com
'''

from __future__ import with_statement
import gdb
import binascii
import struct
import os
import re
import sys
from array import *

program_version="1.10"
minstringlength=3 # how many characters in a row before a value is considered a string

registers64 = ['$rax', '$rcx', '$rdx', '$rbx', '$rsp', '$rbp', '$rsi', '$rdi', '$rip', '$r8', '$r9', '$r10', '$r11', '$r12', '$r13', '$r14']
registers32 = ['$eax', '$ecx', '$edx', '$ebx', '$esp', '$ebp', '$esi', '$edi', '$eip']

global stackFifo
global registerFifo
global disassemblyFifo

# this is where the files for the fifodisplay command are written
tmpdir = '/tmp/' 

# filenames of the various files for the fifodisplay command
s_fifoname = 'stack'
r_fifoname = 'registers'
d_fifoname = 'disassembly'




def deref_long_from_addr (addr) :
	"""Get the value pointed by addr"""
	val = gdb.Value(addr).cast(gdb.lookup_type('long').pointer()).dereference()
	return long(val) & faddress_and



def mach_regions_parser (regions):
	"""Parses info from mach regions command"""
	mslines=regions.split('\n')
	retarray=[]
	for s in mslines:
		if ( (s.find("0x") > -1) & (s.find("---/") == -1) ):
			addresses=s.split(' ')
			addressparts=addresses[0].split('-')
			startaddress=int(addressparts[0], 16)
			endaddress=int(addressparts[1],16)
			size=endaddress-startaddress
			retarray.append([startaddress, endaddress, size])
	return retarray


def proc_info_parser (regions):
	"""Parses info from info proc mappings command"""
	mslines=regions.split('\n')
	retarray=[]
	for s in mslines:
		if (s.find("0x") > -1):
			addresses=s.split()
			startaddress=int(addresses[0], 16)
			endaddress=int(addresses[1],16)
			size=endaddress-startaddress
			retarray.append([startaddress, endaddress, size])
	return retarray


def unicoder( string ):
	return "\x00".join(string) + "\x00"
	

def makeFifo ( filename ):
	"""Makes a fifo for use in output redirection"""
	try:
		os.mkfifo(filename)
	except OSError, e:
		pass
	
	fifo = open(filename, 'w')
	# write stuff to fifo
	#print >> fifo, "hello"
	#fifo.close()
	return fifo
	

def FifoRemover(event):
	RemoveFifo()
	
	
def RemoveFifo():	
	print "Removing fifos"
	try:
		stackFifo.close()
		registerFifo.close()
		disassemblyFifo.close()
	except:
		pass
	try:
		os.remove(tmpdir + s_fifoname)
		os.remove(tmpdir + r_fifoname)
		os.remove(tmpdir + d_fifoname)
	except: 
		pass




def FifoStopHandler(event):
	stackFifo = makeFifo(tmpdir + s_fifoname)
	registerFifo = makeFifo(tmpdir + r_fifoname)
	disassemblyFifo = makeFifo(tmpdir + d_fifoname)
	StackPrinter(20, fifoname=stackFifo)
	RegisterPrinter(fifoname=registerFifo)
	DisassemblyPrinter(20, fifoname=disassemblyFifo)
	stackFifo.flush()
	registerFifo.flush()
	disassemblyFifo.flush()


def DisassemblyPrinter( instructions, fifoname=''):
	if (fifoname):
		output=fifoname
	else:
		output=sys.stdout
		
	print >>output, "=" * 16	
	print >>output, gdb.execute("x/" + str(instructions) + "i $pc", False, True)




def RegisterPrinter(fifoname=''):
	print faddress_and
	if (fifoname):
		output=fifoname
	else:
		output=sys.stdout
	print >> output, '=' * 16
	for a in registers:
		address_str = gdb.parse_and_eval(a)
		data = FancyReader(address_str, False)
		print >> output, ("% 4s - 0x" + faddress_printf + " : %s") %(a, long(address_str.cast(gdb.lookup_type('char').pointer())) & faddress_and, data)


def StackPrinter( arg, fifoname='' ):
	cstack=gdb.parse_and_eval("$sp")
	count=10
	if (fifoname):
		output=fifoname
	else: 
		output=sys.stdout
		
	if (arg):
		count=int(arg)
	
	print >>output, "=" *16
	for a in range(0,count):
		content = long(cstack.cast(gdb.lookup_type('long').pointer()).dereference()) & faddress_and
		address=gdb.Value(content)
		stackdata = FancyReader(address, True)
		print >>output, ("%s: " + faddress_printf + "\t%s") %(cstack, content, stackdata)
		cstack+=stacksize



def ReadMemHex( address, size ):
	pointer=address.cast(gdb.lookup_type('char').pointer())
	output=""
	for a in range(0,size):
		val1= chr(pointer.dereference().cast(gdb.lookup_type('int')) & 0xff)
		output+=binascii.hexlify(val1)
		pointer+=1
	return output


def ReadMemRaw( address, size ):
	pointer=address.cast(gdb.lookup_type('char').pointer())
	output=[]
	for a in range(0,size):
		val1= chr(pointer.dereference().cast(gdb.lookup_type('int')) & 0xff)
		output.append(val1)
		pointer+=1
	return output


def FancyReader( address, hexdump ):
	"""Shows data at given address (as gdb.Value).  Hexdump set to true for hex and ascii"""
	try:
		data = ReadMemAString(address)
		prefix="ASCII: "
	except Exception:
		data=""
		prefix=""
	
	if (len(data) < minstringlength):
		try:
			data = ReadMemUString(address)
			prefix="U: "
		except Exception:
			data=""
			prefix=""
	
	if (len(data) < minstringlength):
		try:
			if hexdump:
				data = ReadMemHexDump(address, 1, False)
				data=data.replace('\n', '')
			else:
				data = ReadMemHex(address, 16)
			prefix="Hex: "
		except Exception:
			data=""
			prefix=""
	
	return prefix+data




def ReadMemHexDump( address, lines, leadaddr ):
	pointer=address.cast(gdb.lookup_type('char').pointer())
	sp=pointer
	asciiwidth=16
	hexwidth=asciiwidth*3
	
	output=""
	for a in range(0,lines):
		
		hexline=""
		asciiline=""
		for b in range(0,asciiwidth):
			v1 = pointer.dereference().cast(gdb.lookup_type('int')) & 0xff
			v2 = binascii.hexlify(chr(v1))
			if ( (v1 > 127) | (v1 == 0x0a) | (v1 == 0x0d) | (v1 == 0x0c) | (v1 == 0x0b) | (v1 == 0) | (v1 == 9) | (v1 == 8) ):
				v1='.'
			else:
				v1=chr(v1)
			hexline+= ' ' + v2
			asciiline+=v1
			pointer+=1
		
		if (leadaddr):
			output+=("0x" + faddress_printf) %(long(sp)) +": "
			sp+=asciiwidth
		output+=hexline+"\t\t"+asciiline+'\n'
		address+=asciiwidth
	return output


def ReadMemAString( address):
	pointer=address.cast(gdb.lookup_type('char').pointer())
	output=""
	while True:
		val1=pointer.dereference().cast(gdb.lookup_type('int')) & 0xff
		pointer+=1
		if ((val1 > 0) & (val1 < 128)):
			output+=chr(val1)
		else:
			break
	return output
		

def ReadMemUString( address):
	pointer=address.cast(gdb.lookup_type('char').pointer())
	output=""
	while True:
		val1=pointer.dereference().cast(gdb.lookup_type('int')) & 0xff
		pointer+=1
		val2=pointer.dereference().cast(gdb.lookup_type('int')) & 0xff
		pointer+=1
		if ((int(val1) > 0) & (int(val1) < 128) & (int(val2) == 0)):
			output+=chr(val1)
		else:
			break
		
	return output
	

def HexToByteArray( hexstring ):
	return array('c', [chr(int((hexstring[i:i+2]),16)) for i in range(0, len(hexstring), 2)])



def CheckPlatform():
	errorstring = "Could not properly determine program architecture to setup environment.  Make sure a target program is attached before reloading extensions."
	global osplatform
	global faddress_printf
	global faddress_and
	global stacksize
	global registers
	osplatform = sys.platform
	try:
		target_info=gdb.execute("info target", False, True)
		mslines=target_info.split('\n')
		targeti=False
		for s in mslines:
			if (s.find("file type") > -1):
				aparts=s.split()
				if (aparts[3].find("64") > -1):
					registers=registers64
					faddress_printf="%016x"
					stacksize=8
					faddress_and=0xffffffffffffffff
				else:
					registers=registers32
					faddress_printf="%08x"
					stacksize=4
					faddress_and=0xffffffff
				print "gdb extensions " + program_version + " loaded"
				targeti=True
				break
		if (not targeti):
			print errorstring
	except:
		print errorstring
	
	
	
CheckPlatform()


class SavePrefixCommand (gdb.Command):
	"Prefix command for saving things."

	def __init__ (self):
		super (SavePrefixCommand, self).__init__ ("save", gdb.COMMAND_SUPPORT, gdb.COMPLETE_NONE, True)

SavePrefixCommand()


class SaveBreakpointsCommand (gdb.Command):
	"""Save the current breakpoints to a file. This command takes a single argument, a file name. The breakpoints can be restored using the 'source' command."""

	def __init__ (self):
		super (SaveBreakpointsCommand, self).__init__ ("save breakpoints", gdb.COMMAND_SUPPORT, gdb.COMPLETE_FILENAME)

	def invoke (self, arg, from_tty):
		if (not arg):
			print "Please provide a filename in which to save breakpoints"
		else:
			with open (arg, 'w') as f:
				bpcount=1
				for bp in gdb.breakpoints ():
					print >> f, "break", bp.location,
					if bp.thread is not None:
						print >> f, " thread", bp.thread,
					if bp.condition is not None:
						print >> f, " if", bp.get_condition,
						print >> f
					if not bp.enabled:
						print >> f, "disable " + str(bpcount)
				
					bpcount+=1
					commands = bp.commands
					if commands is not None:
						print >> f, "commands"
						print >> f, commands,
						print >> f, "end"
						print >> f

SaveBreakpointsCommand ()



class ReadHexMemory(gdb.Command):
	"""Read x number of given bytes from memory and print in hex format"""
	
	def __init__ (self):
		gdb.Command.__init__(self, "readhexmemory", gdb.COMMAND_DATA, gdb.COMPLETE_SYMBOL, True)
		
		
	def invoke (self, arg, from_tty):
		arguments = arg.split(' ')
		if (len(arguments) < 2):
			print "Please provide an address and a size"
		else:
			output=ReadMemHex(gdb.parse_and_eval(str(arguments[0])), int(arguments[1]))
			print output
		
ReadHexMemory()


class ReadHexDumpMemory(gdb.Command):
	"""Read x number of given bytes from memory and print in hex format"""
	
	def __init__ (self):
		gdb.Command.__init__(self, "readhexdumpmemory", gdb.COMMAND_DATA, gdb.COMPLETE_SYMBOL, True)
		
		
	def invoke (self, arg, from_tty):
		arguments = arg.split(' ')
		if (len(arguments) < 2):
			print "Please provide an address and a number of lines"
		else:
			output=ReadMemHexDump(gdb.parse_and_eval(str(arguments[0])), int(arguments[1]), True)
			print output
		
ReadHexDumpMemory()


class ReadString(gdb.Command):
	"""Read a string from memory"""
	
	def __init__ (self):
		gdb.Command.__init__(self, "readstring", gdb.COMMAND_DATA, gdb.COMPLETE_SYMBOL, True)
		
		
	def invoke (self, arg, from_tty):
		if (not arg):
			print "Please provide a memory address to check for a string"
		else:
			char_pointer_type = gdb.lookup_type('char').pointer()
			#address_str = gdb.Value(0xdeadbeef)
			address_str = gdb.parse_and_eval(arg)
			astring = ReadMemAString(address_str)
			ustring = ReadMemUString(address_str)
			if (len(astring) > 1):
				print "ASCII: " + astring
			if (len(ustring) > 1):
				print "Unicode: " + ustring
			#string_pointer = address_str.cast(char_pointer_type)
			#print string_pointer.string()


ReadString()


class SearchString(gdb.Command):
	"""Search for a string in program memory"""
	
	def __init__ (self):
		gdb.Command.__init__(self, "searchstring", gdb.COMMAND_DATA, gdb.COMPLETE_SYMBOL, True)
		
		
	def invoke (self, arg, from_tty):
		if (len(arguments) < 1):
			print "Please provide a string to search for"
		else:
			inferior=gdb.selected_inferior()
			supported=True
			if (osplatform == "linux2"):
				mainsec=gdb.execute("info proc mappings", False, True)
				memregions=proc_info_parser(mainsec)
			elif (osplatform == "darwin"): #OSX
				mainsec=gdb.execute("info mach-regions", False, True)
				memregions=mach_regions_parser(mainsec)
			else:
				supported=False
				print "OS not supported"
			search=str(arg)
			searchu=unicode(search)
			if (supported):
				for region in memregions:
					result = inferior.search_memory(region[0], region[2], search)
					if (isinstance(result, long) & (result < faddress_and) & (result > 0x1)):
						print ("0x" + faddress_printf + ": ASCII: %s") % (result, ReadMemAString(gdb.Value(result)))
					result = inferior.search_memory(region[0], region[2], searchu)
					if (isinstance(result, long) & (result < faddress_and) & (result > 0x1)):
						print ("0x" + faddress_printf + ": Unicode: %s") % (result, ReadMemUString(gdb.Value(result)))



SearchString()


class SearchBinary(gdb.Command):
	"""Search for a binary value in program memory.  Provide input in hex format e.g. 414243ae"""
	
	def __init__ (self):
		gdb.Command.__init__(self, "searchbinary", gdb.COMMAND_DATA, gdb.COMPLETE_SYMBOL, True)
		
		
	def invoke (self, arg, from_tty):
		if (len(arguments) < 1):
			print "Please provide a binary value to search for in hex format e.g. 414243ae"
		else:
			supported=True
			inferior=gdb.selected_inferior()
			if (osplatform == "linux2"):
				mainsec=gdb.execute("info proc mappings", False, True)
				memregions=proc_info_parser(mainsec)
			elif (osplatform == "darwin"): #OSX
				mainsec=gdb.execute("info mach-regions", False, True)
				memregions=mach_regions_parser(mainsec)
			else:
				supported=False
				print "OS not supported"
			search=HexToByteArray(arg)
			if (supported):
				for region in memregions:
					result = inferior.search_memory(region[0], region[2], search)
					if (isinstance(result, long) & (result < faddress_and) & (result > 0x1)):
						print ("0x" + faddress_printf + ": %s") % (result, ReadMemHex(gdb.Value(result), len(arg)/2))




SearchBinary()

class PrintStack(gdb.Command):
	"""Print out the stack all nice like.  First optional parameter is number of lines to print."""
	
	def __init__ (self):
		gdb.Command.__init__(self, "printstack", gdb.COMMAND_DATA, gdb.COMPLETE_SYMBOL, True)
		
		
	def invoke (self, arg, from_tty):
		StackPrinter(arg)

PrintStack()



class PrintRegisters(gdb.Command):
	"""Print out the registers all nice like.  Provide a parameter to send output to a FIFO."""
	
	def __init__ (self):
		gdb.Command.__init__(self, "printregisters", gdb.COMMAND_DATA, gdb.COMPLETE_SYMBOL, True)
		
		
	def invoke (self, arg, from_tty):
		RegisterPrinter()
		
			
		
			
		
PrintRegisters()


class PrintDisassembly(gdb.Command):
	"""Print out disassembly info around $pc"""
	
	def __init__ (self):
		gdb.Command.__init__(self, "printdisassembly", gdb.COMMAND_DATA, gdb.COMPLETE_SYMBOL, True)
		
		
	def invoke (self, arg, from_tty):
		if (arg):
			try:
				instructions=int(arg)
			except Exception:
				pass
		else:
			instructions=20
		DisassemblyPrinter(instructions)

PrintDisassembly()


class PrintExtensionHelp(gdb.Command):
	"""Print out a list of commands included with the extension"""
	
	def __init__ (self):
		gdb.Command.__init__(self, "printextensionhelp", gdb.COMMAND_DATA, gdb.COMPLETE_SYMBOL, True)
		
		
	def invoke (self, arg, from_tty):
		ExtensionHelp()
		

PrintExtensionHelp()


class FifoEventDisplay(gdb.Command):
	"""Enables handlers to send program data to specially named fifo pipes on program break"""

	def __init__ (self):
		gdb.Command.__init__(self, "fifodisplay", gdb.COMMAND_DATA, gdb.COMPLETE_SYMBOL, True)
		
		
	def invoke (self, arg, from_tty):
		if (arg != "Stop" and arg != "stop" ):
			global er
			er = gdb.events
			er.stop.connect(FifoStopHandler)
			er.exited.connect(FifoRemover)
			
			print "Adding handler.  Use 'fifodisplay stop' to remove."
			print "Program execution will now pause while you create fifo listeners (e.g. use 'tail -f <filename>')"
			print "-----------------------------"
			print "Create a fifo listener for file " + tmpdir + s_fifoname + " to display the stack"
			stackFifo = makeFifo(tmpdir + s_fifoname)
			print "-----------------------------"
			print "Now create a fifo listener for " + tmpdir + r_fifoname + " to display register values"
			registerFifo = makeFifo(tmpdir + r_fifoname)
			print "-----------------------------"
			print "And finally, create a fifo listener for " + tmpdir + d_fifoname + " to display disassembly information"
			disassemblyFifo = makeFifo(tmpdir + d_fifoname)
			print "-----------------------------"
			print "Done!"
		else:
			print "Removing handler"
			try:
				er.stop.disconnect(FifoStopHandler)
				er.exited.disconnect(FifoRemover)
			except: 
				pass
			RemoveFifo()


FifoEventDisplay()


class NextOver(gdb.Command):
	"""A next over command to skip over calls in assembly and not break on new threads"""

	def __init__ (self):
		gdb.Command.__init__(self, "no", gdb.COMMAND_DATA, gdb.COMPLETE_SYMBOL, True)
		
		
	def invoke (self, arg, from_tty):
		ci=gdb.execute("x/2i $pc", False, True)
		count=0
		for a in ci.split('\n'):
			if (count==0):
				[chuck, command] = a.split('>:')
				command = command.replace('\t','')
			elif ('<' in a):
				bits = a.split('<')
				address = bits[0].replace(' ', '')
				
			count+=1
		
		gdb.Breakpoint('*'+address, gdb.BP_BREAKPOINT, 0, True) # silent breakpoint
		out = gdb.execute("c", False, True).replace('\n', '')
		[one, two] = out.split(', ')
		print two
		gdb.breakpoints()[-1].delete() # delete last added breakpoint

		

NextOver()

class NextIn(gdb.Command):
	"""A next in command to step into calls and not break on new threads in assembly"""


	def __init__ (self):
		gdb.Command.__init__(self, "ns", gdb.COMMAND_DATA, gdb.COMPLETE_SYMBOL, True)
		
		
	def invoke (self, arg, from_tty):
		ci=gdb.execute("x/2i $pc", False, True)
		count=0
		for a in ci.split('\n'):
			if (count==0):
				[chuck, command] = a.split('>:')
				command = command.replace('\t','')
			elif ('<' in a):
				bits = a.split('<')
				address = bits[0].replace(' ', '')
				
			count+=1
		command = re.sub('\s+',' ',command)
		if (command.startswith('call')):
			cbits=command.split(' ')
			print cbits[1]
			address= ("0x" + faddress_printf) %(long(cbits[1], 16))
		gdb.Breakpoint('*'+address, gdb.BP_BREAKPOINT, 0, True) # silent breakpoint
		out = gdb.execute("c", False, True).replace('\n', '')
		[one, two] = out.split(', ')
		print two
		gdb.breakpoints()[-1].delete() # delete last added breakpoint
		

NextIn()

def ExtensionHelp():
	print """save breakpoints - save breakpoints to a file.  These breakpoints can then be read back into a new session using the built in gdb 'source' command.
	
readhexmemory - prints in hex format a given number of bytes from a given address in memory.

readhexdumpmemory - prints out a given number of lines (16 bytes per line) of a hex dump of memory starting at a given address. Each line contains the hex value for each byte as well as its ASCII representation, in a similar fashion as you would see in a Hex editor.

readstring - prints out any string located at a given address in memory.  Works with ASCII and basic Unicode strings.

searchstring - searches allocated program memory for a given string, and prints out all discovered instances along with their associated memory addresses.  Works for ASCII and simple Unicode strings.  Only linux and Masc OSX supported.  Warnings may appear when certain sections of memory cannot be searched - these are nothing to worry about.

searchbinary - searches allocated program memory for binary data, provided in hex format, e.g. 414243ae. Only linux and Masc OSX supported. Warnings may appear when certain sections of memory cannot be searched - these are nothing to worry about.

printstack - prints out a given number of lines of the stack view, including the address, the value stored in memory at that address and, if the stack entry could be interpreted as a pointer, any data (string if possible, hex if not) stored at that address.  If the number of lines is ommitted, a value of 10 is assumed.

printregisters - prints out the registers, along with contextual information of the data located at the memory address stored by each register.

printdisassembly - prints out the disassembly for the code located at the instruction pointer register.

fifodisplay - registers a number of handlers to automatically run the printstack, print registers and printdisassembly commands each time the program pauses, and to send the output to fifo pipes created in the current working directory named stack, registers and disassembly.  Combined with a multiple paned terminal window, can give you contextual information simialr to OllyDbg. Use the Stop parameter to disable the handlers.

no - Does an assembly level step operation that will skip over 'call' function calls and wont break on new threads.

ns - Does an assembly level step operation that will skip into 'call' operations and wont break on new threads.

printextensionhelp - prints this help output
"""
