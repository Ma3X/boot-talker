import os
from setuptools import setup
from nvpy import nvpy

def findFiles(directory,ext):
    res=os.listdir(directory)
    res=[os.path.join(directory,f) for f in res if f.endswith(ext)]
    return res

setup(
    name = "debugui",
    version = "0.11",
    author = "Amir Geva",
    author_email = "amirgeva@gmail.com",
    description = "User Interface for GDB",
    license = "GPLv2",
    url = "http://sourceforge.net/projects/debugui",
    packages=['debugui'],
    entry_points = {
        'console_scripts' : ['debugui = debugui.debugui:main']
    },
    data_files = [
        ('share/debugui/parsers', findFiles('debugui/parsers','py')),
        ('share/debugui/icons', findFiles('debugui/icons','png')),
        ('share/debugui/gdb_printers/python', 
               ['debugui/gdb_printers/python/hook.in',
                'debugui/gdb_printers/python/Makefile.am',
                'debugui/gdb_printers/python/Makefile.in']),
        ('share/debugui/gdb_printers/python/libstdcxx',
               ['debugui/gdb_printers/python/libstdcxx/__init__.py']),
        ('share/debugui/gdb_printers/python/libstdcxx/v6',
               ['debugui/gdb_printers/python/libstdcxx/v6/printers.py',
                'debugui/gdb_printers/python/libstdcxx/v6/__init__.py'])
    ],
    classifiers=[
        "License :: OSI-Approved Open Source :: GNU General Public License version 2.0 (GPLv2)",
    ],
)

