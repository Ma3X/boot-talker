#!/usr/bin/env python
from PySide import QtCore
from PySide import QtGui
import sys
import os
from gdbwrapper import GDBWrapper
from gdbwindow import GDBWindow

def main():
    """ Creates the main window and runs the application
    
    In package deployment, root usually gets a value of:
    /usr/share/debugui
    (depending on sys.prefix)
    
    For development, use the DEBUGUI env var to indicate the 
    directory where the 'parsers' and 'icons' sub-dirs are
    
    """

    if len(sys.argv)<2:
        print "Usage: debugui <program> [params]"
    else:
        app=QtGui.QApplication(sys.argv)
        QtCore.QCoreApplication.setOrganizationName("MLGSoft")
        QtCore.QCoreApplication.setOrganizationDomain("mlgsoft.com")
        QtCore.QCoreApplication.setApplicationName("DebuGui")
        root=os.getenv('DEBUGUI','')
        if len(root)==0:
            root=os.path.join(sys.prefix,"share/debugui")
        dbg=GDBWrapper(root,sys.argv[1:])
        w=GDBWindow(root)
        w.setDebugger(dbg)
        w.show()
        app.exec_()
        

if __name__=='__main__':
    main()
    
