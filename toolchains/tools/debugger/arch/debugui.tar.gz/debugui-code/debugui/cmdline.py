# -*- coding: utf-8 -*-
"""
Created on Wed Sep 25 20:24:33 2013

@author: amir
"""

import sys


opts={}
params=[]


n=len(sys.argv)
i=1
while i<n:
    a=sys.argv[i]
    if a[0]=='-':
        if len(a)>1 and i<(n-1):
            opts[a[1:]]=sys.argv[i+1]
            i+=1
        else:
            raise Exception('Invalid arguments')
    else:
        params.append(a)
        i+=1
