from PySide import QtCore
from PySide import QtGui
import os
from codeedit import CodeEditor
import parseutils
from watchestree import WatchesTree

class GDBWindow(QtGui.QMainWindow):
    """ Main Debugger Window

    Contains the main code view, along with docking panes for: source files,    
    watches, call stack, and output
    
    """
    
    def __init__(self,rootDir,parent=None):
        """ Initialize.  rootDir indicates where data files are located """
        super(GDBWindow,self).__init__(parent)
        self.setMinimumSize(QtCore.QSize(1024,768))

        self.currentLine=0
        self.currentFile=''
        
        self.setWindowIcon(QtGui.QIcon(os.path.join(rootDir,'icons','bug.png')))
        
        self.runningWidget=None
        self.editor=CodeEditor()
        self.setCentralWidget(self.editor)
        self.setupMenu()
        self.setupToolbar(rootDir)
        self.timer=QtCore.QTimer(self)
        self.timer.timeout.connect(self.update)
        self.timer.start(50)

    def update(self):
        """ Called every 50ms to check if a change in debugger state occurred
        
        Basically this is waiting for a change of state, indicated by:
        * self.debugger.changed
        
        If a change is detected, everything is re-evaluated and drawn
        
        """
        if self.debugger:
            text=self.debugger.update()
            if len(text)>0:
                self.addOutputText(text)
            if self.debugger.changed:
                self.updatePosition()
                self.updateWatches()
                self.updateCallstack()
                self.debugger.changed=False
        # If the debugger is active running the program,
        # create an indication using an animation in the top left
        # corner of the application window
        if self.debugger.active:
            if self.runningWidget is None:
                from running import RunningWidget
                self.runningWidget=RunningWidget(self)
                self.runningWidget.show()
        elif not self.runningWidget is None:
            self.runningWidget.close()
            self.runningWidget=None
            

    def closeEvent(self, event):
        """ Called before the application window closes

        Informs sub-windows to prepare and saves window settings
        to allow future sessions to look the same
        
        """
        self.timer.stop()
        self.debugger.closingApp()
        self.editor.closingApp()
        settings = QtCore.QSettings()
        settings.setValue("geometry", self.saveGeometry())
        settings.setValue("windowState", self.saveState())
        settings.sync()
        super(GDBWindow,self).closeEvent(event)

    def setupMenu(self):
        """ Creates the application main menu 
        
        The action handlers are also mapped from the toolbar icons
        
        """
        bar=self.menuBar()
        m=bar.addMenu('&Debug')
        m.addAction(QtGui.QAction('&Step',self,shortcut='F11',triggered=self.actStep))
        m.addAction(QtGui.QAction('&Next',self,shortcut='F10',triggered=self.actNext))
        m.addAction(QtGui.QAction('Step &Out',self,shortcut='Shift+F11',triggered=self.actOut))
        m.addAction(QtGui.QAction('&Continue',self,shortcut='F5',triggered=self.actCont))
        m.addAction(QtGui.QAction('&Break',self,shortcut='Ctrl+C',triggered=self.actBreak))
        m.addAction(QtGui.QAction('Sto&p',self,shortcut='Shift+F5',triggered=self.actStop))
        m=bar.addMenu('&Settings')
        m.addAction(QtGui.QAction('&Fonts',self,triggered=self.settingsFonts))

    def setupToolbar(self,rootDir):
        """ Creates the application main toolbar """
        tb=self.addToolBar('Actions')
        tb.setObjectName("Toolbar")
        dir=os.path.join(rootDir,'icons')
        #print "Loading toolbar icons from '{}'".format(dir)
        tb.addAction(QtGui.QIcon(os.path.join(dir,'step.png')),'Step').triggered.connect(self.actStep)
        tb.addAction(QtGui.QIcon(os.path.join(dir,'next.png')),'Next').triggered.connect(self.actNext)
        tb.addAction(QtGui.QIcon(os.path.join(dir,'out.png')),'Out').triggered.connect(self.actOut)
        tb.addAction(QtGui.QIcon(os.path.join(dir,'cont.png')),'Continue').triggered.connect(self.actCont)
        tb.addAction(QtGui.QIcon(os.path.join(dir,'break.png')),'Break').triggered.connect(self.actBreak)
        tb.addAction(QtGui.QIcon(os.path.join(dir,'stop.png')),'Stop').triggered.connect(self.actStop)
        self.addToolBar(tb)

    def settingsFonts(self):
        """ Edit the font settings for the code window and various panes """
        from settings import FontSettingsDialog
        d=FontSettingsDialog()
        if d.exec_():
            self.setAllFonts()
            
    def loadFont(self,name,target):
        """ Load previously saved font settings """
        settings=QtCore.QSettings()
        fb=settings.value(name)
        if not fb is None:
            buf=QtCore.QBuffer(fb)
            buf.open(QtCore.QIODevice.ReadOnly)
            font=QtGui.QFont()
            QtCore.QDataStream(fb) >> font
            target.setFont(font)
        else:
            target.setFont(QtGui.QFont('monospace',14))
        
    def setAllFonts(self):
        """ Apply fonts to the various sub-windows """
        self.loadFont('codefont',self.editor.code)
        self.loadFont('watchesfont',self.watchesTree)
        self.loadFont('watchesfont',self.stackList)
        self.loadFont('watchesfont',self.outputEdit)
        self.loadFont('sourcesfont',self.FilesViewList)

    def actStep(self):
        if not self.debugger is None:
            self.debugger.actStep()

    def actNext(self):
        if not self.debugger is None:
            self.debugger.actNext()

    def actOut(self):
        if not self.debugger is None:
            self.debugger.actOut()

    def actCont(self):
        if not self.debugger is None:
            self.debugger.actCont()

    def actBreak(self):
        if not self.debugger is None:
            self.debugger.actBreak()

    def actStop(self):
        if not self.debugger is None:
            self.debugger.actStop()

    def showFileListPane(self):
        """ Creates a docking pane that shows a list of source files """
        self.paneFiles=QtGui.QDockWidget("Source Files",self)
        self.paneFiles.setObjectName("Sources")
        self.paneFiles.setAllowedAreas(QtCore.Qt.LeftDockWidgetArea|QtCore.Qt.RightDockWidgetArea)
        self.FilesViewList=QtGui.QListWidget(self.paneFiles)
        self.FilesViewList.itemClicked.connect(lambda item: self.loadItem(item))
        self.paneFiles.setWidget(self.FilesViewList)
        self.addDockWidget(QtCore.Qt.LeftDockWidgetArea,self.paneFiles)

    def showCallStackPane(self):
        self.paneStack=QtGui.QDockWidget("Call Stack",self)
        self.paneStack.setObjectName("CallStack")
        self.paneStack.setAllowedAreas(QtCore.Qt.BottomDockWidgetArea)
        self.stackList=QtGui.QListWidget(self.paneStack)
        self.paneStack.setWidget(self.stackList)
        self.addDockWidget(QtCore.Qt.BottomDockWidgetArea,self.paneStack)
    
    def showWatchesPane(self):
        self.paneWatches=QtGui.QDockWidget("Watches",self)
        self.paneWatches.setObjectName("Watches")
        self.paneWatches.setAllowedAreas(QtCore.Qt.BottomDockWidgetArea)
        self.watchesTree=WatchesTree(self.paneWatches)
        self.watchesTree.setColumnCount(2)
        self.watchesTree.setHeaderLabels(['Name','Value'])
        self.paneWatches.setWidget(self.watchesTree)
        self.addDockWidget(QtCore.Qt.BottomDockWidgetArea,self.paneWatches)
        
        self.watchesTree.addTopLevelItem(QtGui.QTreeWidgetItem(['* Double-Click for new watch']))
        self.watchesTree.resizeColumnToContents(0)
        self.watchesTree.itemDoubleClicked.connect(lambda item,column : self.watchDoubleClicked(item,column))
        self.loadWatches()
        
    def showOutputPane(self):        
        self.paneOutput=QtGui.QDockWidget("Output",self)
        self.paneOutput.setObjectName("Output")
        self.paneOutput.setAllowedAreas(QtCore.Qt.BottomDockWidgetArea)
        self.outputEdit=QtGui.QPlainTextEdit(self.paneOutput)
        self.outputEdit.setReadOnly(True)
        self.paneOutput.setWidget(self.outputEdit)
        self.addDockWidget(QtCore.Qt.BottomDockWidgetArea,self.paneOutput)
        
    def addOutputText(self,added):
        """ Append the new text captured
        
        Text is appended to the end of existing text and the widget
        is scrolled to show the end 
        
        """
        text=self.outputEdit.toPlainText()
        self.outputEdit.setPlainText(text+added)
        c=self.outputEdit.textCursor()
        c.movePosition(QtGui.QTextCursor.End)
        self.outputEdit.setTextCursor(c)
        self.outputEdit.ensureCursorVisible()
        
    def watchDoubleClicked(self,item,column):
        """ Edits existing watches, or adds a new watch """
        changed=False
        index=self.watchesTree.indexOfTopLevelItem(item)
        if item.text(column)=='* Double-Click for new watch':
            res=QtGui.QInputDialog.getText(self,'New Watch','Expression')
            expr=res[0]
            if len(expr)>0 and res[1]:
                self.watchesTree.insertTopLevelItem(index,QtGui.QTreeWidgetItem([expr]))
                changed=True
                self.updateWatches()
        else:
            watch=item.text(0)
            res=QtGui.QInputDialog.getText(self,"Edit Watch",'Expression',text=watch)
            watch=res[0]
            if res[1]:
                changed=True
                if len(watch)>0:
                    item.setText(0,watch)
                    self.updateWatches()
                else:
                    self.watchesTree.takeTopLevelItem(index)
        if changed:
            self.saveWatches()

    def updateFileList(self):
        self.FilesViewList.clear()
        self.paths=self.debugger.getAllFiles()
        for f in self.paths:
            self.FilesViewList.addItem(os.path.basename(f))
        
    def setDebugger(self,dbg):
        self.debugger=dbg
        self.editor.setDebugger(dbg)
        self.showFileListPane()
        self.updateFileList()
        self.showWatchesPane()
        self.showCallStackPane()
        self.showOutputPane()
        self.setAllFonts()
        settings=QtCore.QSettings()
        self.restoreGeometry(settings.value("geometry"))
        self.restoreState(settings.value("windowState"))

    def updatePosition(self):
        """ Query current position and update the code view """
        (path,line)=self.debugger.getCurrentPos()
        changed=(self.currentLine!=line)
        self.currentLine=line
        if len(path)>0 and self.currentFile!=path:
            self.loadFile(path)
            self.currentFile=path
            changed=True
        if changed:
            self.editor.code.setCurrentLine(self.currentFile,self.currentLine)

    def saveWatches(self):
        """ Save all watches to settings, for future sessions """
        res=[]
        n=self.watchesTree.topLevelItemCount()-1
        for i in xrange(0,n):
            item=self.watchesTree.topLevelItem(i)
            if len(res)>0:
                res.append(';')
            res.append(item.text(0))
        settings=QtCore.QSettings()
        key='watches:{}'.format(self.debugger.debugged)
        settings.setValue(key,''.join(res))
        
    def loadWatches(self):
        """ Load all previous session watches from settings """
        while self.watchesTree.topLevelItemCount()>1:
            self.watchesTree.takeTopLevelItem(0)
        settings=QtCore.QSettings()
        key='watches:{}'.format(self.debugger.debugged)
        val=settings.value(key,'')
        if len(val)>0:
            arr=val.split(';')
            if len(arr)>0:
                res=[]
                for watch in arr:
                    res.append(QtGui.QTreeWidgetItem([watch]))
                self.watchesTree.insertTopLevelItems(0,res)
        

    def updateWatches(self):
        """ Re-evaluate the value of each watch and update view """
        n=self.watchesTree.topLevelItemCount()-1
        for i in xrange(0,n):
            item=self.watchesTree.topLevelItem(i)
            item.takeChildren()
            expr=item.text(0)
            res=self.debugger.evaluate(expr)
            if len(res)==0:
                item.setText(1,'')
            else:
                if res[0]=='string' or res[0]=='number':
                    item.setText(1,res[1])
                elif res[0]=='vector' or res[0]=='list':
                    del res[0]
                    parseutils.addSequence(item,res)
                elif res[0]=='map':
                    del res[0]
                    parseutils.addMapping(item,res)
                elif res[0]=='struct':
                    item.setText(1,parseutils.flatten(res))
                    del res[0]
                    parseutils.addMapping(item,res)
                    
    def updateCallstack(self):
        bt=self.debugger.getBackTrace()
        self.stackList.clear()
        for line in bt:
            self.stackList.addItem(line)
    
    
    def loadItem(self,item):
        """ Loads the file that the file list item matches """
        i=self.FilesViewList.row(item)
        path=self.paths[i]
        self.loadFile(path)
        self.updatePosition()
        self.editor.code.setCurrentLine(self.currentFile,self.currentLine)
        
    def loadFile(self,path):
        """ Loads a source file by path """
        try:
            f=open(path,"r")
            self.setWindowTitle(path)
            self.editor.code.setText(path,f.read())
        except OSError:
            # Display file not found error
            pass

