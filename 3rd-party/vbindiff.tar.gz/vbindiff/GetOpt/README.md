Free GetOpt
===========

Free GetOpt is a C++ class for parsing command line arguments.  It is not currently well documented; consult the source for usage information.


Copyright and License
=====================

Free GetOpt is copyright 2000 by Christopher J. Madsen

This program is free software; you can redistribute it and/or modify it under the terms of the [GNU General Public License](http://www.gnu.org/licenses/gpl.html) as published by the Free Software Foundation; either [version 2 of the License](http://www.gnu.org/licenses/old-licenses/gpl-2.0.html), or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

As a special exception, if you link Free GetOpt with other files to produce an executable, this does not by itself cause the resulting executable to be covered by the GNU General Public License.  Your use of that executable is in no way restricted on account of linking the Free GetOpt code into it.  However, if you link a modified version of Free GetOpt to your executable and distribute the executable, you must make your modifications to Free GetOpt publicly available as machine-readable source code.

This exception does not however invalidate any other reasons why the executable file might be covered by the GNU General Public License.

This exception applies only to the code released under the name Free GetOpt.  If you copy code from other programs into a copy of Free GetOpt, as the General Public License permits, the exception does not apply to the code that you add in this way.  To avoid misleading anyone as to the status of such modified files, you must delete this exception notice from them.

If you write modifications of your own for Free GetOpt, it is your choice whether to permit this exception to apply to your modifications. If you do not wish that, delete this exception notice.
